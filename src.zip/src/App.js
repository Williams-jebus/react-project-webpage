import React from 'react';
import './App.css'
import { useState } from 'react';

function App() {

  const [details, setdetails] = useState([])
  const [list, setlist] = useState([])
  const [editIndex, setEditIndex] = useState(null)

 const handlesubmit = () =>{
      if (editIndex !== null) {
      const updatedList = [...list];
      updatedList[editIndex] = [details ]; // store as object
      setlist(updatedList);
      setEditIndex(null);
      }
      else{
      setlist([...list,details])
      }
 }
 const handleedit = (index) =>{
  setdetails(list[index])
  setEditIndex(index)
 }
 const handlereset = () =>{
  setlist([''])
 }
  
return (
<div className='input'> 
<center>
  <label>Name : </label><input className='name' type='text' placeholder='Name' name='details' value={details} onChange={ (event) =>{setdetails(event.target.value)}} ></input><br></br>
  <button onClick={handlesubmit} className='submit'>{editIndex !== null ? 'Update' : 'Submit'}</button>
  <button onClick={handlereset}  className='reset'>Reset</button>
</center>
{
  list.map((items,index) => (
   <ul key={index}>
       <li>{items}</li><button onClick={() => {handleedit(index)}}>Edit</button>
   </ul>
  ))
}
</div>
)
}

export default App